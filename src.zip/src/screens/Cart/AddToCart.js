import { View , Text} from "react-native";

const AddToCart = ()=>{

    return(
        <View>
            <Text>AddToCart</Text>
        </View>
    )
}

export default AddToCart;